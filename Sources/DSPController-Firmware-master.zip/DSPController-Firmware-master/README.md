#DSPController-Firmware

This repository contains the source code of the firmware that runs on the DSPController interface device. 
The code is fully documented with Doxygen comments.

Generated documentation file is included.
