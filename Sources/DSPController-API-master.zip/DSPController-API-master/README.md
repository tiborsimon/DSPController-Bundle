#DSPController-API


The source code of the DSPController API. It can be used with the Analog Devices SHARC ADSP-21364 evaluation board.
